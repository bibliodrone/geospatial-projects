# **MAKE SURE THAT 'MARC21slimUtils' XSLT STYLESHEET IS IN THE 'outputs' FOLDER BEFORE RUNNING THIS SCRIPT!**

# Update variable CDP_XSL to point to latest XSL file (declared on line 163)

import csv
import os
import lxml.etree as ET
import datetime
import urllib.request

    
# --- Function definitions --- #

def getTodaysDate():
    today = str(datetime.date.today()).replace('-', '')
    return(today)

# Compile list of tuples as (string, replacement), and set the replacement values 
# for the current XML file. Used in replaceTargetStrings()
def setReplaceStrings(row):
    rep=[]
    
    # xxx_SoftwareVersion_xxx
    SoftwareVersion = str(row['ArcGIS_version'])
    if SoftwareVersion.upper().isupper() == False:
        SoftwareVersion = "ArcMap " + SoftwareVersion
    rep.append(('xxx_SoftwareVersion_xxx', SoftwareVersion))
    
    # xxx_EPSG_xxx
    EPSG_code = row['EPSG_code']
    rep.append(('xxx_EPSG_xxx', EPSG_code))
    
    # xxx_Production_Date_xxx
    Date_Production = row['Date_Production']
    rep.append(('xxx_Production_Date_xxx', Date_Production))
    
    # rProjection
    rProjection = row['Coord_Syst'].replace('_', ' ')
    rep.append(('rProjection', rProjection))
    
    # rRMS
    try:
        rRMS = row['RMS_error']
    except:
        rRMS = "0"
    rep.append(('rRMS', rRMS))
    
    # rUnits (from RMS0)
    try:
        RMS0 = row['RMS_error']
    except:
        RMS0 = '0'
    if RMS0 == '0':
        rUnits = row['units'] + '. The RMS error for this map is listed as 0 because at least 4 control points must be used to calculate an RMS error'
    else:
        rUnits = row['units']
    rep.append(('rUnits', rUnits))
    
    # rDataSources    
    rDataSources = row['Georeferenced_to..'].replace('_', ' ')
    rep.append(('rDataSources', rDataSources))
    
    # xxx_GeoRefNote_xxx
    if row['notes'] == '':
        GeoRefNote = '';
    else:
        GeoRefNote = '\n\n\t\t\tGeoreferencing note: ' + row['notes'] + '\n\n\t\t\t'
    rep.append(('xxx_GeoRefNote_xxx', GeoRefNote))
    
    # xxx_PubMonth_xxx
    currentDate = datetime.datetime.now()
    cYear = str(currentDate.year)
    cMonth = str(currentDate.month).zfill(2)
    PubMonth = cYear + cMonth
    rep.append(('xxx_PubMonth_xxx', PubMonth))
    
    return rep

def updateXSLT(CDP_batch_path, rLayerReplace):
    todaysdate = getTodaysDate()
    #update XSLT file so that it contains current XML file that is being edited
    # 1) Read in the original XSLT file
    with open(CDP_XSL, 'r') as file :
        
        filedata = file.read()
        # Replace the target string with current XML file name
        filedata = filedata.replace('rLayerID', rLayerReplace)
        filedata = filedata.replace('CDP_batch_path', CDP_batch_path)
        #insert current date
        filedata = filedata.replace('xxx_todaysdate_xxx', todaysdate)
        # A simple fix for an extra period after the 'Scale' phrase in the abstract (unless we discover side-effects)
        filedata = filedata.replace('].. ', ']. ')
    
    # Write out modified xsl file as outputXSLT.xsl
    with open('outputs_CDP_/outputXSLT.xsl', 'w') as file:
        file.write(filedata)
    #print ('outputXSLT updated for', rLayerReplace)
            

def getHollisRecord(hollis_num, hollis_xml):
    #hollis_xml = save xml filename
    urllib.request.urlretrieve ('http://webservices.lib.harvard.edu/rest/marc/hollis/' + hollis_num, hollis_xml)
    #print(f"MARC record {hollis_num} downloaded from API")
    
def transformXSL(hollis_xml, output_xsl, xml_output):
    dom = ET.parse(hollis_xml)
    xslt = ET.parse(output_xsl)

    transform = ET.XSLT(xslt)
    newdom = transform(dom)
    newdom.write(xml_output, pretty_print=True, xml_declaration=True, encoding='UTF-8')

    #print ('Output XSLT transformation run')

def createFinalXML(xml_output, final_xml):
    with open(xml_output, encoding="utf-8") as f:
        tree = ET.parse(f)
        root = tree.getroot()
        tree.write(final_xml, xml_declaration=True, method='xml', encoding='utf-8')    
    
def replaceTargetStrings(final_xml, replaceStrings):
    with open(final_xml, 'r', encoding='utf-8') as final :
        filedata = final.read()
        for r in replaceStrings:
            filedata=filedata.replace(r[0], r[1])
            
    with open(final_xml, 'w+', encoding='utf-8') as final_final:
        final_final.write(filedata)

        
def removeTempFiles():
    #remove left-over xml files (APIdownload, XSLToutput) after program has run.
    relPath = "./outputs_CDP_/"
    
    f_list = [f for f in os.listdir(relPath) if f.endswith('APIdownload.xml') or f.endswith('XSLToutput.xml')]

    xsltcounter=0
    apidcounter=0
    errorcounter=0

    for file in f_list:
        #print(file)
        if file.endswith('APIdownload.xml'):
            apidcounter+=1
        elif file.endswith('XSLToutput.xml'):
            xsltcounter+=1
        else:
            errorcounter+=1

    print(f"Deleting {apidcounter} *APIdownload.xml files and {xsltcounter} *XSLToutput.xml files from {relPath}")

    if len(f_list)>0:
        for item in f_list:
            #os.rename(item, (relPath + item)) could move files instead, if desired.
            os.remove(relPath + item)
            

# --- Main code --- #
            
filePath='./outputs_CDP_/'
# --- XSL filename to use --- #
CDP_XSL = 'CDP_single_sheet_20200221.xsl'
# ----------------------------#
newCDP = 'spreadsheets/newCDP.csv'
xmlToEdit = 'xml_to_edit.csv'
cleanTempFiles = False #controls whether extra XSL and API download XMLs are deleted after script has run.

recordCount = 0

listOfFileNames = []

print(f"\nUsing source XSL file '{CDP_XSL}'\n\n")
print(f"Saving files to '/outputs_CDP_/final/' ... \n")

# open xml_to_edit.csv file with list of xml files (exported FGDC records from ArcGIS) for editing
# Compiles list of filenames to edit, which will be matched against 'newCDP.csv' in the next step.
with open(xmlToEdit) as xmlList:
    XMLreader = csv.DictReader(xmlList)
    #iterate over list
    for line in XMLreader:
        fn = line['file_name']
        listOfFileNames.append(fn)

#open csv file containing target information pulled from Dani's georef spreadsheets (CDP or OnSite csv)
with open(newCDP) as csvFile:

    #parse as a dictionary (OwnerSuppliedName can be used as a key)
    CSVreader = csv.DictReader(csvFile)

    for row in CSVreader: 
        '''
        Match current XML file to information pulled from georef csv using OwnerSuppliedName as a key
        Original script relies on having the arcmpaExports .xml files copied manually by the user into the 
        same directory with outputXSLT.xsl; this version instead adds the folder pathway using the CDP_batch
        column in newCDP.csv to recreate the directory name for the current record's corresponding '_export.xml' file.
        * Assumes each batch folder is named with only one number; e.g.: 'arcmapExports_batch_87' will be opened, 
          but 'arcmapExports_batch_87_88' will not work.
        '''
        osn = row['OwnerSuppliedName']
        #fileName = line['file_name']
        if osn in listOfFileNames:
            #print(f"#{recordCount}:")
            rLayerReplace = osn
            CDP_batch_path = "../arcmapExports_batch_" + row["CDP_batch"]
            hollis_num = row['HOLLIS'] # changed HOLLIS
            output_xsl = "./outputs_CDP_/outputXSLT.xsl" #changed f_xsl
            hollis_xml = "./outputs_CDP_/" + osn + "_APIdownload.xml" #changed f_xml
            xml_output = "./outputs_CDP_/" + osn + "_XSLToutput.xml" #changed f_out
            final_xml  = "./outputs_CDP_/final/" + osn + ".xml"

            replaceStrings = setReplaceStrings(row)

            updateXSLT(CDP_batch_path, rLayerReplace)

            try:
                hollis_record = getHollisRecord(hollis_num, hollis_xml)
            except:
                print("Could not retrieve record from HOLLIS API.")

            transformXSL(hollis_xml, output_xsl, xml_output)

            createFinalXML(xml_output, final_xml)

            replaceStrings = setReplaceStrings(row)

            replaceTargetStrings(final_xml, replaceStrings)

            print(f"  {osn}.xml")
            #print("{0:^20}".format("-" * 3))
            recordCount += 1


# Enable function call below to delete unnecessary .xml files after the main program loop has ended. 
# Alternatively, could move this call under 'recordCount += 1' to delete temporary files at end of each
# iteration

print(f"\nProcessed {recordCount} files.\n")
print(f"Clean temp files: {cleanTempFiles}")

if cleanTempFiles:
    removeTempFiles()
   