# HOLLIS_xml_scraper.py
# Look for a target tag in HOLLIS marcxml records (*_APIdownload.xml) in outputs_CDP_
# Useful to identify MARC records with fields matching a certain pattern for XSL testing.from bs4 import BeautifulSoup as bs

import os

def testForTag(i, targetTags):
    with open(i, "r", encoding="utf-8", errors="ignore") as marc:
        soup = bs(marc, "lxml")
        marc_tags = soup.find_all("datafield")
        for targetTag in targetTags:
            for marc_tag in marc_tags:
                # print(marc_tag.get('tag'))
                tagNum = marc_tag.get('tag')
                if targetTag == tagNum:
                    #print(f"\n\n{i}")
                    print("\n", tagNum, end="")
                    subfields = marc_tag.find_all("subfield")
                    for sf in subfields:
                        sf_code = sf.get('code')
                        #if sf.get('code') == "a":
                        sfString = sf.string
                        #print(f"|{sf.get('code')} {sf.string}", end=" ")
                        print(f"|{sf_code} {sf.string}", end=" ")
                            
                           
                              
filepath = "./outputs_CDP_/api_downloads/"
targetTags = ["255"]

marcfiles = [f for f in os.listdir(filepath) if f.endswith('.xml')]

if len(marcfiles) > 0:
    for i in marcfiles:
        # print(i)
        print("\n", end="-")
        fullPath = filepath + i
        testForTag(fullPath, targetTags)
else:
    print(f"No files with {targetTags} found.")