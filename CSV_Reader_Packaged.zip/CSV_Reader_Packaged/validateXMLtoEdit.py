# Validate xml_to_edit
# 
# Return title and CDP_batch number from a row in newCDP.csv if there is an 
# 'owner_supplied_filename' matching a row in xml_to_edit.csv

import csv

xmlToEdit = []
noMatch = 0
rowCount = 0
matchCount = 0

with open('./xml_to_edit.csv') as xmltoedit:
    reader1 = csv.DictReader(xmltoedit)
    for row1 in reader1:
        xmlToEdit.append(row1['file_name'])
        
#print(xmlToEdit)

with open('./spreadsheets/newCDP.csv') as csvFile:
    reader = csv.DictReader(csvFile)
    print("Checking xml_to_edit.csv filenames against newCDP.csv filename listings: \n")
    for row in reader:
        #print(row['OwnerSuppliedName'],': HOLLIS#', row['HOLLIS'],',', row['ArcGIS_version'],',', row['Georeferenced_to..'],',', row['RMS_error '], row['units'],',', row['Coord_Syst'],'(', row['EPSG_code'],'),', row['Date_Production'],',', row['notes'])
        osn = row['OwnerSuppliedName']
        if osn in xmlToEdit:
            cdp_batch = row['CDP_batch']
            print(f"{cdp_batch} -- {osn}")
            matchCount+=1
        else:
            noMatch+=1
        rowCount+=1
        
    print(f"\n\nThere were {matchCount} matches and {noMatch} non-matches out of {rowCount} total filenames in newCDP.csv ")

    checksum = (matchCount + noMatch) == rowCount

    if checksum:
        #print(f"All {rowCount} rows accounted for.")
        print()
    else:
        discrepancy = abs(rowCount - (matchCount+noMatch))
        print(f"{discrepancy} rows not accounted for.")